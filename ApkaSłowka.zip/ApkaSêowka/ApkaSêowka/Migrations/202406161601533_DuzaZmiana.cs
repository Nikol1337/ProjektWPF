﻿namespace ApkaSłowka.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DuzaZmiana : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Slowkoes", "CzyMoznaDodac", c => c.Boolean(nullable: false));
            AddColumn("dbo.Slowkoes", "CzyMoznaUsunac", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Slowkoes", "CzyMoznaUsunac");
            DropColumn("dbo.Slowkoes", "CzyMoznaDodac");
        }
    }
}
