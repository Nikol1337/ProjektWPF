﻿namespace ApkaSłowka.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class wersja01 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.KategoriaSłówek",
                c => new
                    {
                        KategoriaSłówekId = c.Int(nullable: false, identity: true),
                        Nazwa = c.String(),
                    })
                .PrimaryKey(t => t.KategoriaSłówekId);
            
            AddColumn("dbo.Slowkoes", "KategoriaSłówek_KategoriaSłówekId", c => c.Int());
            CreateIndex("dbo.Slowkoes", "KategoriaSłówek_KategoriaSłówekId");
            AddForeignKey("dbo.Slowkoes", "KategoriaSłówek_KategoriaSłówekId", "dbo.KategoriaSłówek", "KategoriaSłówekId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Slowkoes", "KategoriaSłówek_KategoriaSłówekId", "dbo.KategoriaSłówek");
            DropIndex("dbo.Slowkoes", new[] { "KategoriaSłówek_KategoriaSłówekId" });
            DropColumn("dbo.Slowkoes", "KategoriaSłówek_KategoriaSłówekId");
            DropTable("dbo.KategoriaSłówek");
        }
    }
}
