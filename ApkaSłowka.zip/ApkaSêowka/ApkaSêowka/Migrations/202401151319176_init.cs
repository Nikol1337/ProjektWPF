﻿namespace ApkaSłowka.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class init : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Slowkoes",
                c => new
                    {
                        SlowkoId = c.Int(nullable: false, identity: true),
                        polskie = c.String(),
                        angielskie = c.String(),
                        Znane = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.SlowkoId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Slowkoes");
        }
    }
}
