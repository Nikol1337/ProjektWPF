﻿namespace ApkaSłowka.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Statystyki : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Slowkoes", "PoprawneOdpowiedzi", c => c.Int(nullable: false));
            AddColumn("dbo.Slowkoes", "NiepoprawneOdpowiedzi", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Slowkoes", "NiepoprawneOdpowiedzi");
            DropColumn("dbo.Slowkoes", "PoprawneOdpowiedzi");
        }
    }
}
