﻿using ApkaSłowka.BazaDanych;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ApkaSłowka.Klasy;
using ApkaSłowka.strony;
using System.Globalization;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace ApkaSłowka
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DBContext dbContext;
        private ITryb aktualnyTryb;
        Frame main;
        public MainWindow()
        {
            dbContext = DBContext.GetInstance;
            InitializeComponent();
            main= MainFrameSingleton.Instance;

            UstawAktualnyTryb(new TrybNauki());
            aktualnyTryb.RozpocznijNauke();

            MainGrid.Children.Add(main);
        }
        //Funkcje wzorca STAN
        private void UstawAktualnyTryb(ITryb tryb)
        {
            aktualnyTryb = tryb;
        }
        private void ZmienTryb_Click(object sender, RoutedEventArgs e)
        {
            
            UstawAktualnyTryb(new TrybPowtorki());
        }
        
        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabItem selectedTab = (TabItem)e.AddedItems[0];
           // StronaTestu stronaTestu = new StronaTestu();

            switch (selectedTab.Header.ToString())
            {
                case "Strona Główna":
                    main.Navigate(new DodawanieSlowek());
                    MainFrame.Navigating += MainFrame_Navigating;
                    break;
                case "Nauka":
                    UstawAktualnyTryb(new TrybNauki());
                    aktualnyTryb.RozpocznijNauke();
                    // mainFrame.Navigate(new StronaNauki());
                    break;
                case "Powtórka":
                    UstawAktualnyTryb(new TrybPowtorki());
                    main.Navigate(new StronaWyboruTPowtorki());
                    MainFrame.Navigating += MainFrame_Navigating;
                    break;
                case "Testy":
                    UstawAktualnyTryb(new TrybTestu());
                    Console.WriteLine("JESTEM TU");
                    aktualnyTryb.RozpocznijNauke();
                  //  mainFrame.Navigate(new StronaTestu());
                    break;
            }
        }

        private void MainFrame_Navigating(object sender, NavigatingCancelEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(MainFrame);

            // Przerywamy nawigację, aby pozwolić animacji zakończyć się
            e.Cancel = true;

            // Przygotowanie do nawigacji do nowej strony po zakończeniu animacji
            Dispatcher.BeginInvoke((Action)(() =>
            {
                MainFrame.Navigate(e.Content);
            }), DispatcherPriority.Loaded);
        }

    }
    public class MainFrameSingleton
    {
        private static Frame instance;

        private MainFrameSingleton() { }

        public static Frame Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Frame();
                   
                    instance.Name = "mainFrame";
                    instance.Margin = new Thickness(10, 27, 10, 10);
                    instance.NavigationUIVisibility = NavigationUIVisibility.Hidden;
                    
                }
                return instance;
            }
        }
    }

    

    public class TabItemForegroundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool isSelected = (bool)value;
            return isSelected ? new SolidColorBrush(Color.FromArgb(255, 54, 54, 54)) : new SolidColorBrush(Colors.White);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class TabItemBackgroundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool isSelected = (bool)value;
            return isSelected ? new SolidColorBrush(Color.FromRgb(46, 46, 46)) : new SolidColorBrush(Color.FromRgb(39, 39, 39));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

}

