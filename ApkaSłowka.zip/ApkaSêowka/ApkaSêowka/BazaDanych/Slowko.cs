﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ApkaSłowka.BazaDanych
{

    public interface IKomponentSłówek
    {
        string Wyświetl();
    }
    public class SlowkoStatystyki : INotifyPropertyChanged
    {
        public string polskie { get; set; }
        public string angielskie { get; set; }
        public float PoprawneOdpowiedzi { get; set; }
        public float NiePoprawneOdpowiedzi { get; set; }

        public SlowkoStatystyki(Slowko slowo)
        {
            polskie = slowo.polskie;
            angielskie = slowo.angielskie;
            float suma = slowo.PoprawneOdpowiedzi + slowo.NiepoprawneOdpowiedzi;
            if (suma != 0)
            {
                PoprawneOdpowiedzi = (float)Math.Round((slowo.PoprawneOdpowiedzi / suma) * 100, 1);
                NiePoprawneOdpowiedzi = (float)Math.Round((slowo.NiepoprawneOdpowiedzi / suma) * 100, 1);
            }
            else
            {
                PoprawneOdpowiedzi=0;
                NiePoprawneOdpowiedzi = 0;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
    public class Slowko : IKomponentSłówek, INotifyPropertyChanged
    {
        [Key]
        public int SlowkoId { get; set; }
        public string polskie { get; set; }
        public string angielskie { get; set; }
        public bool Znane { get; set; }
        private bool _czyMoznaDodac;

        public int PoprawneOdpowiedzi {  get; set; }
        public int NiepoprawneOdpowiedzi { get; set; }
        public bool CzyMoznaDodac
        {
            get => _czyMoznaDodac;
            set
            {
                _czyMoznaDodac = value;
                OnPropertyChanged(nameof(CzyMoznaDodac));
            }
        }

        private bool _czyMoznaUsunac;
        public bool CzyMoznaUsunac
        {
            get => _czyMoznaUsunac;
            set
            {
                _czyMoznaUsunac = value;
                OnPropertyChanged(nameof(CzyMoznaUsunac));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public string Wyświetl()
        {
            return  polskie+" "+angielskie;
        }
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            Slowko other = (Slowko)obj;
           
            return this.polskie.Equals(other.polskie) && this.angielskie.Equals(other.angielskie);
        }
        public override int GetHashCode()
        {
            
            return new { this.polskie, this.angielskie }.GetHashCode();
        }
    }
    public class KategoriaSłówek : IKomponentSłówek
    {
        public int KategoriaSłówekId { get; set; }
        public string Nazwa { get; set; }
        public virtual List<Slowko> Słówka { get; set; } = new List<Slowko>();
        public string Wyświetl()
        {
           return Słówka.Count().ToString();
        }

    }
   
}
