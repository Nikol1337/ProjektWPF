﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace ApkaSłowka.BazaDanych
{
    

    public class DBContext : DbContext
    {
        private static DBContext instance;
        private static readonly object LockObject = new object();

        public DbSet<Slowko> WszystkieSlowka { get; set; }
        public DbSet<KategoriaSłówek> KategorieSlowek { get; set; }

        // Private constructor to prevent direct instantiation
        public DBContext() : base("name=ConnectionString")
        {
        }

        // Singleton instance accessor
        public static DBContext GetInstance
        {
            get
            {
                if (instance == null)
                {
                    lock (LockObject)
                    {
                        if (instance == null)
                        {
                            instance = new DBContext();
                        }
                    }
                }
                return instance;
            }
        }
    }
}
