﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApkaSłowka.BazaDanych;

using System.Windows.Input;
using System.Diagnostics;
using LiveCharts;
using LiveCharts.Wpf;


namespace ApkaSłowka.Klasy
{
    public class SlowniczekViewModel: INotifyPropertyChanged
    {
        private KategoriaSłówek _wybranaKategoria;
        private KategoriaSłówek _wybranaKategoriaFilter;
        public ObservableCollection<Slowko> ListaSlowek { get; set; }
        public ObservableCollection<KategoriaSłówek> KategorieSlowek { get; set; }
        public ICommand TrudneSlowkaCommand { get; set; }
        public ICommand LatweSlowkaCommand { get; set; }
        public SeriesCollection SeriesCollection { get; set; }

        public KategoriaSłówek WybranaKategoria
        {
            get => _wybranaKategoria;
            set
            {
                Debug.WriteLine("wybranakategoria set");
                _wybranaKategoria = value;
                OnPropertyChanged(nameof(WybranaKategoria));
                OnPropertyChanged(nameof(WybranaKategoriaOpis));
                AktywujButtonyDodawaniaKategorii();
                

            }
        }
        public KategoriaSłówek WybranaKategoriaFilter
        {
            get => _wybranaKategoriaFilter;
            set
            {
                _wybranaKategoriaFilter = value;
                OnPropertyChanged(nameof(WybranaKategoriaFilter));
                AktualizujListeSlowek(); // Aktualizuj listę po zmianie wybranej kategorii do filtrowania
            }
        }

        public string WybranaKategoriaOpis => WybranaKategoria != null ? $"{WybranaKategoria.Nazwa} zawiera {WybranaKategoria.Słówka.Count} elementów" : string.Empty;

        public ICommand DodajDoKategoriiCommand { get; set; }
        public ICommand UsunZKategoriiCommand { get; set; }
        public ICommand ZmienCzyZnaneCommand { get; set; }
        public ICommand SortujPoPolskimCommand { get; set; }
        public ICommand SortujPoAngielskimCommand { get; set; }
        public SlowniczekViewModel()
        {
            // Inicjalizacja kolekcji i komend
            ListaSlowek = new ObservableCollection<Slowko>();
            KategorieSlowek = new ObservableCollection<KategoriaSłówek>();
            DodajDoKategoriiCommand = new PrzekazKomende<Slowko>(DodajDoKategorii);
            UsunZKategoriiCommand = new PrzekazKomende<Slowko>(UsunZKategorii);
            ZmienCzyZnaneCommand = new PrzekazKomende<Slowko>(ZmienCzyZnane);
            TrudneSlowkaCommand = new PrzekazKomende<object>(OnTrudneClicked);
            LatweSlowkaCommand = new PrzekazKomende<object>(OnLatweClicked);
            SortujPoPolskimCommand = new PrzekazKomende<object>(_ => SortujListeSlowekPoPolskim());
            SortujPoAngielskimCommand = new PrzekazKomende<object>(_ => SortujListeSlowekPoAngielskim());



            SeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = "Dobre odpowiedzi",
                    Values = new ChartValues<int> { 10, 5, 6, 8 } // Przykładowe dane
                },
                new ColumnSeries
                {
                    Title = "Złe odpowiedzi",
                    Values = new ChartValues<int> { 5, 7, 3, 2 } // Przykładowe dane
                }
            };
            // Dodaj dane przykładowe lub załaduj je z bazy danych
        }
        private void OnTrudneClicked(object obj)
        {
            WybranaKategoria = KategorieSlowek.FirstOrDefault(k => k.Nazwa == "Trudne");
        }
        private void AktualizujListeSlowek()
        {
            if (WybranaKategoriaFilter.Nazwa == "Wszystkie")
            {
                List<Slowko> wszystkieSlowka = new List<Slowko>();
                foreach (var kategoria in KategorieSlowek)
                {
                    wszystkieSlowka.AddRange(kategoria.Słówka);
                }
                ListaSlowek = new ObservableCollection<Slowko>(wszystkieSlowka);
            }else
            if (WybranaKategoriaFilter != null)
            {
                ListaSlowek = new ObservableCollection<Slowko>(WybranaKategoriaFilter.Słówka);
            }
            else
            {
                ListaSlowek = new ObservableCollection<Slowko>(); // Czyścimy listę, jeśli nie wybrano kategorii
            }

            OnPropertyChanged(nameof(ListaSlowek));
        }
        private void OnLatweClicked(object obj)
        {
            WybranaKategoria = KategorieSlowek.FirstOrDefault(k => k.Nazwa == "Łatwe");
        }
        private void DodajDoKategorii(Slowko slowo)
        {
            Debug.WriteLine("Dodaj do kategori");
            if (WybranaKategoria != null)
            {
                WybranaKategoria.Słówka.Add(slowo);

                // Zmiany w bazie danych
                DBContext db = DBContext.GetInstance;
                var slowoToRemove = db.WszystkieSlowka.First(s => s.SlowkoId == slowo.SlowkoId);
                db.WszystkieSlowka.Remove(slowoToRemove);
                db.SaveChanges();
                db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.Add(slowo);
                db.SaveChanges();
                AktywujButtonyDodawaniaKategorii();
                //ListaSlowek.Remove(slowo);
                OnPropertyChanged(nameof(WybranaKategoriaOpis));
            }
        }

        private void UsunZKategorii(Slowko slowo)
        {
            var slowko = slowo;
            Debug.WriteLine("Usun z kategori");
            if (WybranaKategoria != null)
            {
                WybranaKategoria.Słówka.Remove(slowo);

                // Zmiany w bazie danych
                DBContext db = DBContext.GetInstance;
                //var slowoToRemove = db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
                var slowoToRemove = db.WszystkieSlowka.First(s => s.SlowkoId == slowo.SlowkoId);
                db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.Remove(slowoToRemove);
                db.SaveChanges();
                db.WszystkieSlowka.Add(slowo);
                db.SaveChanges();
                //ListaSlowek.Add(slowo);
                AktywujButtonyDodawaniaKategorii();
                OnPropertyChanged(nameof(WybranaKategoriaOpis));
            }
        }

        private void ZmienCzyZnane(Slowko slowo)
        {
            DBContext db = DBContext.GetInstance;
            var slowoToUpdate = db.WszystkieSlowka.Find(slowo.SlowkoId);
            if (slowoToUpdate != null)
            {
                slowoToUpdate.Znane = slowo.Znane;
                db.SaveChanges();
                slowo.Znane = slowoToUpdate.Znane;
            }
        }

        private void SortujListeSlowekPoPolskim()
        {
            ListaSlowek = new ObservableCollection<Slowko>(ListaSlowek.OrderBy(s => s.polskie));
            OnPropertyChanged(nameof(ListaSlowek));
        }
        private void SortujListeSlowekPoAngielskim()
        {
            ListaSlowek = new ObservableCollection<Slowko>(ListaSlowek.OrderBy(s => s.angielskie));
            OnPropertyChanged(nameof(ListaSlowek));
        }
        private void AktywujButtonyDodawaniaKategorii()
        {

            Debug.WriteLine("Aktywj buttony");
            foreach (var slowo in ListaSlowek)
            {
                slowo.CzyMoznaDodac = WybranaKategoria == null || !WybranaKategoria.Słówka.Contains(slowo);
                slowo.CzyMoznaUsunac = WybranaKategoria != null && WybranaKategoria.Słówka.Contains(slowo);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
