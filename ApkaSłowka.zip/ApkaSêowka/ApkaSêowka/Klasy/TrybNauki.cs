﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using ApkaSłowka.BazaDanych;
using ApkaSłowka.strony;

namespace ApkaSłowka.Klasy
{
    public interface ITryb
    {
        void RozpocznijNauke();
    }
    public class TrybNauki:ITryb
    {
        Frame mainFrame;
        List<Slowko> wszystkieOdpowiedzi = new List<Slowko>();
        List<KategoriaSłówek> listaKategorii = new List<KategoriaSłówek>();
       public TrybNauki()
        {
            this.mainFrame = MainFrameSingleton.Instance; 
            PobierzSlowkaDoNauki();
        }
        public void RozpocznijNauke()
        {
            Slowniczek slownik = new Slowniczek(wszystkieOdpowiedzi,listaKategorii);
            mainFrame.Navigate(slownik);
            
        }
        private void PobierzSlowkaDoNauki()
        {
            var dbContext = DBContext.GetInstance;
            wszystkieOdpowiedzi = dbContext.WszystkieSlowka.ToList();
            listaKategorii=dbContext.KategorieSlowek.ToList();
        }
    }
    public class TrybPowtorki : ITryb
    {
        public ITypNauki aktualnyTypNauki;
        public void RozpocznijNauke()
        {
            
        }
        public void UstawAktualnyTypNauki(ITypNauki typNauki)
        {
            aktualnyTypNauki = typNauki;
        }
    }

    // Implementacja dla trybu testu
    public class TrybTestu : ITryb
    {
        private Frame mainFrame;
        //Wzorzec obserwator- lista obiektow do obserwowania
        private List<IKreatorListener> kreatorzy = new List<IKreatorListener>();
        private List<Slowko> wszystkieOdpowiedzi=new List<Slowko>();
        private List<KategoriaSłówek> wszystkieKategorie = new List<KategoriaSłówek>();

        public TrybTestu()
        {
            this.mainFrame = MainFrameSingleton.Instance;
            KreatorTestowLatwych kreatorŁatwy=new KreatorTestowLatwych();
            KreatorTestowSrednich kreatorSrednich=new KreatorTestowSrednich();
            KreatorTestowTrudnych kreatorTrudnych=new KreatorTestowTrudnych();
            kreatorzy.Add(kreatorŁatwy);
            kreatorzy.Add(kreatorSrednich);
            kreatorzy.Add(kreatorTrudnych);
            
        }
        //Metoda ktora powiadamia wszystkie kreatory z listy o liscie dostepnych slowek- OBSERWATOR
        private void PowiadamiajKreatorow(List<Slowko> slowkaDoTestu,List<KategoriaSłówek> kategorie)
        {
            foreach (var kreator in kreatorzy)
            {
                kreator.Informuj(slowkaDoTestu,mainFrame,kategorie);
            }
        }
        public void RozpocznijNauke()
        {
            

            // Rozpoczynamy naukę
            PowiadamiajKreatorow(PobierzSlowkaDoTestu(),PobierzKategorieDoTestu());
            if (mainFrame != null)
            {
                StronaTestu stronaTestu = new StronaTestu(kreatorzy);
                mainFrame.Navigate(stronaTestu);
            }
            else
            {
                // Obsługa przypadku, gdy mainFrame jest null
                Console.WriteLine("mainFrame nie został ustawiony.");
            }
        }
        private List<Slowko> PobierzSlowkaDoTestu()
        {
            var dbContext = DBContext.GetInstance;
            wszystkieOdpowiedzi = dbContext.WszystkieSlowka.ToList();
            return wszystkieOdpowiedzi;
        }
        private List<KategoriaSłówek> PobierzKategorieDoTestu()
        {
            var dbContext = DBContext.GetInstance;
            wszystkieKategorie = dbContext.KategorieSlowek.ToList();
            return wszystkieKategorie;
        }
    }
}
