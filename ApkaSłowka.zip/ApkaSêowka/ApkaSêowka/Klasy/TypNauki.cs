﻿using ApkaSłowka.BazaDanych;
using ApkaSłowka.strony;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using static System.Net.Mime.MediaTypeNames;

namespace ApkaSłowka.Klasy
{
    public class Pytanie
    {
        public string TrescPytania { get; set; }
        public List<Slowko> MozliweOdpowiedzi { get; set; }
        public string PoprawnaOdpowiedz { get; set; }
        public int idSlowa { get; set; }
    }
    public interface ITypNauki
    {
        
        void AlgorytmSzablonowy();
    }

   
    public abstract class NaukaPoprzezTest : ITypNauki
    {
        public void AlgorytmSzablonowy()
        {
            PobierzDane();
            RozpocznijNauke();
        }
        public abstract void RozpocznijNauke();
        public abstract void PobierzDane();
        public abstract Pytanie stworzTest(Slowko slowo);
        public abstract List<Slowko> LosujMozliweOdpowiedzi(Slowko wybraneSlowo);

        public virtual Slowko LosujSlowo(List<Slowko> slowka)
        {
            // Implementacja funkcji wybierającej losowe słowo
            Random random = new Random();
            return slowka.OrderBy(x => random.Next()).FirstOrDefault();
        }

        // Metoda abstrakcyjna do losowania słów
        

        // Metoda szablonowa, która jest wspólna dla różnych typów nauki
        public Pytanie WykonajTest<T>(Func<IKomponentSłówek, Pytanie> stworzTest, Frame mainFrame)
        {
            List<Slowko> slowka = PobierzSlowkaZBazy();
            Slowko slowo = LosujSlowo(slowka);

           

            
           Pytanie test = stworzTest(slowo);
            return test;

          
          

        }

        // Metoda szablonowa do generowania XML dla konkretnego testu
        protected void GenerujXmlTestu(List<Pytanie> pytania, Frame mainFrame,int iloscPytan)
        {
            TestWielokrotnyWybor stronaTestu = new TestWielokrotnyWybor(pytania,mainFrame,iloscPytan,"Angielski");
            mainFrame.Navigate(stronaTestu);
            


        }

        private List<Slowko> PobierzSlowkaZBazy()
        {
            var dbContext = DBContext.GetInstance;
            
                return dbContext.WszystkieSlowka.ToList();
            
        }
    }
    public class NaukaPoprzezWpisywanieSlow : ITypNauki
    {
        Frame mainFrame;
        List<Slowko> wszystkieOdpowiedzi;
        List<Slowko> wybranePytaniaDoTestu;
        public NaukaPoprzezWpisywanieSlow(Frame mainFrame)
        {
            this.mainFrame = mainFrame;
            wybranePytaniaDoTestu = new List<Slowko>();
            var dbContext = DBContext.GetInstance;
            wszystkieOdpowiedzi = dbContext.WszystkieSlowka.ToList();
        }
        public void AlgorytmSzablonowy()
        {
            for (int i = 0; i < 5; i++)
            {
                
                Slowko slowo = WybierzLosoweSlowo(wszystkieOdpowiedzi);
                
                wybranePytaniaDoTestu.Add(slowo);
                wszystkieOdpowiedzi.Remove(slowo);
                
            }
            StronaTestuWpisywanie strona = new StronaTestuWpisywanie(wybranePytaniaDoTestu,mainFrame);
            mainFrame.Navigate(strona);
            
        }
        private Slowko WybierzLosoweSlowo(List<Slowko> slowka)
        {
            
            Random random = new Random();
            return slowka.OrderBy(x => random.Next()).FirstOrDefault();
        }
       
    }
    
    public class NaukaPoprzezTestWielokrotnegoWyboruLuka : NaukaPoprzezTest
    {
        Frame mainFrame;
        private List<Pytanie> pytania = new List<Pytanie>();
        List<Response[]> resp;
        List<Slowko> wszystkieOdpowiedzi;
        List<Pytanie> pytaniaDoTestu;
        int iloscPytan = 3;



        public NaukaPoprzezTestWielokrotnegoWyboruLuka(Frame mainFrame)
        {
            this.mainFrame = mainFrame;
            
           
           
            pytaniaDoTestu = new List<Pytanie>();
            resp= new List<Response[]>();
           
           
        }
        private int LosujLiczbe(int ilosc)
        {
            Random random = new Random();

            
            int losowaLiczba = random.Next(0,ilosc);
            return losowaLiczba;
        }
        public override Pytanie stworzTest(Slowko slowo)
        {
            Pytanie pytanie = new Pytanie();
            pytanie.PoprawnaOdpowiedz = slowo.angielskie;
            pytanie.idSlowa = slowo.SlowkoId;

           Response[] odpowiedz = API.StartSynchronously(slowo);
            if(odpowiedz == null)
            {
                return null;
            }
            int numer = LosujLiczbe(odpowiedz.Count() - 1);
            int ilosc = odpowiedz[0].Examples.Count();

            pytanie.TrescPytania = odpowiedz[0].Examples[numer].SourcePrefix + "...." + odpowiedz[0].Examples[numer].SourceSuffix + "\n" + odpowiedz[0].Examples[numer].TargetPrefix + "..." + odpowiedz[0].Examples[numer].TargetSuffix;
            pytanie.MozliweOdpowiedzi = LosujMozliweOdpowiedzi(slowo);
           
            resp.Add(odpowiedz);

            return pytanie;
        }
        public override void RozpocznijNauke()
        {
            
            for (int i = 0; i < iloscPytan; i++)
            {
                
                Slowko slowo = LosujSlowo(wszystkieOdpowiedzi);

                
                Pytanie NOWE = WykonajTest<Slowko>(slowkonowe => stworzTest(slowo), mainFrame);
                if(NOWE == null)
                {
                    MessageBoxResult result = MessageBox.Show("Czy usunąć?: "+ slowo.polskie + ", " + slowo.angielskie, "Brak zdania w bazie", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if(result == MessageBoxResult.Yes)
                    {
                        DBContext.GetInstance.WszystkieSlowka.Remove(slowo);
                        DBContext.GetInstance.SaveChanges();
                    }

                    i--;
                }else
                pytania.Add(NOWE);
            }

            GenerujXmlTestu(pytania, mainFrame, iloscPytan);

           
        }
        
        public override void PobierzDane()
        {
            var dbContext = DBContext.GetInstance;
            wszystkieOdpowiedzi = dbContext.WszystkieSlowka.ToList();
        }
        public override List<Slowko> LosujMozliweOdpowiedzi(Slowko wybraneSlowo)
        {
           
            Random random = new Random();

            // Losowanie odpowiedzi
            var losoweOdpowiedzi = wszystkieOdpowiedzi.OrderBy(x => random.Next()).Take(3).ToList();
            

            
            // Losowe dodanie odpowiedzi prawidłowej na jedną z pozycji
            int indexDodanejOdpowiedzi = random.Next(4);
            if (indexDodanejOdpowiedzi == 3)
            {
                losoweOdpowiedzi.Add(wybraneSlowo);
            }
            else
            {
                losoweOdpowiedzi.Insert(indexDodanejOdpowiedzi, wybraneSlowo);
            }
            
            return losoweOdpowiedzi;

        }

    }
    public class NaukaPoprzezTestWielokrotnegoWyboruTłumaczenie : NaukaPoprzezTest
    {
        private Frame mainFrame;
        private List<Pytanie> pytania=new List<Pytanie>();
        List<Slowko> wszystkieOdpowiedzi;
        int iloscpytan = 4;
        public NaukaPoprzezTestWielokrotnegoWyboruTłumaczenie(Frame mainFrame)
        {
           this.mainFrame = mainFrame;  
        }
        public override void RozpocznijNauke()
        {
            for(int i = 0; i < iloscpytan; i++) { 
          
            Slowko slowo = LosujSlowo(wszystkieOdpowiedzi);
           

           Pytanie NOWE= WykonajTest<Slowko>(slowkonowe => stworzTest(slowo),mainFrame);
                pytania.Add(NOWE);
            }

            GenerujXmlTestu(pytania, mainFrame,iloscpytan);
            
        }
        public override void PobierzDane()
        {
            var dbContext = DBContext.GetInstance;
            wszystkieOdpowiedzi = dbContext.WszystkieSlowka.ToList();
        }
        public override Pytanie stworzTest(Slowko slowo)
        {

            Pytanie test = new Pytanie
            {
                TrescPytania = $"Wybierz prawdiłową odpowiedz: {slowo.angielskie} to po polsku...",
                MozliweOdpowiedzi = LosujMozliweOdpowiedzi(slowo),
                PoprawnaOdpowiedz = slowo.polskie,
                idSlowa = slowo.SlowkoId
            };

            return test;
        }
        public override List<Slowko> LosujMozliweOdpowiedzi(Slowko slowo)
        {
                // Usunięcie odpowiedzi prawidłowej z listy, aby uniknąć powtórzeń
                wszystkieOdpowiedzi.Remove(slowo);

               
                Random random = new Random();

                // Losowanie odpowiedzi
                var losoweOdpowiedzi = wszystkieOdpowiedzi.OrderBy(x => random.Next()).Take(3).ToList();

                // Losowe dodanie odpowiedzi prawidłowej na jedną z pozycji
                int indexDodanejOdpowiedzi = random.Next(4);
                if (indexDodanejOdpowiedzi == 3)
                {
                    losoweOdpowiedzi.Add(slowo);
                }
              else
                {
                    losoweOdpowiedzi.Insert(indexDodanejOdpowiedzi, slowo);
                }

                return losoweOdpowiedzi;
            
        }

       
        
        

    }



}
