﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApkaSłowka.Klasy;
using ApkaSłowka.BazaDanych;
using System.Windows.Controls;
namespace ApkaSłowka.Klasy
{
    public enum RodzajTestu
    {
        Latwy,
        Sredni,
        Trudny
    }
    public interface IKreatorListener
    {
       
        void Informuj(List<Slowko> slowka, Frame main, List<KategoriaSłówek> kategorie);
        void StworzTest();
    }

    // Klasa bazowa dla kreatora
    public abstract class Kreator : IKreatorListener
    {
        Frame mainFrame;
        public virtual RodzajTestu RodzajTestu => RodzajTestu.Latwy;
        List<KategoriaSłówek> slowka = new List<KategoriaSłówek>();
        List<Slowko> slowko = new List<Slowko>();
        public virtual void Informuj(List<Slowko> slowka, Frame main, List<KategoriaSłówek> kategorie)
        {
            mainFrame = main;
            this.slowka = kategorie;
            slowko = slowka;
        }
        public abstract void StworzTest();
        
    }
    public class KreatorTestowLatwych : Kreator
    {
        Frame mainFrame;
        public override RodzajTestu RodzajTestu => RodzajTestu.Latwy;

        List<Slowko> slowka = new List<Slowko>();
        List<KategoriaSłówek> listaKategorii = new List<KategoriaSłówek>();
        List<Slowko> slowko = new List<Slowko>();
        public override void Informuj(List<Slowko> slowka, Frame main, List<KategoriaSłówek> kategorie)
        {
           
            mainFrame = main;
            this.slowka = slowka;
            listaKategorii = kategorie;
            slowko = slowka;

        }
        public override void StworzTest()
        {
            TestLatwy latwy = new TestLatwy(listaKategorii,slowko);
            latwy.WykonajTest();
        }
    }

    // Klasa dla kreatora testów średnich
    public class KreatorTestowSrednich : Kreator
    {
        Frame mainFrame;
        public override RodzajTestu RodzajTestu => RodzajTestu.Sredni;
        List<Slowko> slowka = new List<Slowko>();
        public override void Informuj(List<Slowko> slowka, Frame main, List<KategoriaSłówek> kategorie)
        {
           
            mainFrame=main;
            this.slowka = slowka;
           

            
        }
        public override void StworzTest()
        {
            TestSredni sredni = new TestSredni(slowka);
            sredni.WykonajTest(); 
        }
    }

    // Klasa dla kreatora testów trudnych
    public class KreatorTestowTrudnych : Kreator
    {
        Frame mainFrame;
        public override RodzajTestu RodzajTestu => RodzajTestu.Trudny;
        List<Slowko> slowka=new List<Slowko>();
        public override void Informuj(List<Slowko> slowka, Frame main,List<KategoriaSłówek> kategorie)
        {
            
            mainFrame = main;
            this.slowka = slowka;

           
        }
        public override void StworzTest()
        {
            TestTrudny trudny = new TestTrudny(slowka);
           trudny.WykonajTest();
        }
    }
}
