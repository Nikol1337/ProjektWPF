﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using ApkaSłowka.BazaDanych;
using ApkaSłowka.strony;
namespace ApkaSłowka.Klasy
{
    

    public interface ITest
    {
       
        void WykonajTest();
    }

    // Implementacja różnych rodzajów testów
    public class TestLatwy : ITest
    {
       
        List<KategoriaSłówek> slowaDoTestu = new List<KategoriaSłówek>();

        List<Slowko> slowaWszystkie = new List<Slowko>();
        Frame mainFrame;
        public TestLatwy(List<KategoriaSłówek> slowa,List<Slowko> wsztystkie) {
            slowaWszystkie = wsztystkie;
            this.mainFrame = MainFrameSingleton.Instance;
            slowaDoTestu = slowa;
        
        }
        public void WykonajTest()
        {
            EgzaminLatwy egzamin=new EgzaminLatwy(slowaWszystkie,slowaDoTestu,mainFrame);
            mainFrame.Navigate(egzamin);
            Console.WriteLine("Test łatwy");
            
        }

    }

    public class TestSredni : ITest
    {
        List<Slowko> wszystkieOdpowiedzi = new List<Slowko>();
        private Frame mainFrame;
        private List<Pytanie> pytania = new List<Pytanie>();

        int iloscpytanLuki = 3;
        int iloscpytanTlumaczenie = 2;
        
        public TestSredni(List<Slowko> slowa)
        {
            this.mainFrame = MainFrameSingleton.Instance;



            wszystkieOdpowiedzi = slowa;

        }
         
        public void WykonajTest()
        {
            WylosujPytaniaLuki();
            WylosujPytaniaTlumaczenie();
            Console.WriteLine("Test średni");
            int iloscPytan = iloscpytanLuki + iloscpytanTlumaczenie;
            EgzaminSredni egzamin = new EgzaminSredni(pytania, iloscPytan,mainFrame);
            mainFrame.Navigate(egzamin);
           
        }
       

       
        

        private void WylosujPytaniaLuki()
        {
            for (int i = 0; i < iloscpytanLuki; i++)
            {
                Slowko wybrane = LosujSlowo(wszystkieOdpowiedzi);
                Pytanie pytanie = new Pytanie();
                pytanie.PoprawnaOdpowiedz = wybrane.angielskie;
                pytanie.idSlowa = wybrane.SlowkoId;

                Response[] odpowiedz = API.StartSynchronously(wybrane);
                int numer = LosujLiczbe(odpowiedz.Count() - 1);
                int ilosc = odpowiedz[0].Examples.Count();
                if (ilosc == 0)
                {
                    iloscpytanLuki--;
                    continue;
                }
                pytanie.TrescPytania = odpowiedz[0].Examples[numer].SourcePrefix + "...." + odpowiedz[0].Examples[numer].SourceSuffix + "\n" + odpowiedz[0].Examples[numer].TargetPrefix + "..." + odpowiedz[0].Examples[numer].TargetSuffix;
                wszystkieOdpowiedzi.Remove(wybrane);
                pytanie.MozliweOdpowiedzi = LosujMozliweOdpowiedzi(wybrane);
                pytania.Add(pytanie);
            }
        }

        private void WylosujPytaniaTlumaczenie()
        {
            for (int i = 0; i < iloscpytanTlumaczenie; i++)
            {
                Slowko wybrane = LosujSlowo(wszystkieOdpowiedzi);
                Pytanie pytanie = new Pytanie();
                pytanie.PoprawnaOdpowiedz = wybrane.angielskie;
                pytanie.idSlowa = wybrane.SlowkoId;

                pytanie.TrescPytania = $"Wybierz prawdiłową odpowiedz: {wybrane.polskie} to po angielsku...";
                wszystkieOdpowiedzi.Remove(wybrane);
                pytanie.MozliweOdpowiedzi = LosujMozliweOdpowiedzi(wybrane);
                pytania.Add(pytanie);
            }
        }

        private int LosujLiczbe(int ilosc)
        {
            Random random = new Random();

            
            int losowaLiczba = random.Next(0, ilosc);
            return losowaLiczba;
        }

        public Slowko LosujSlowo(List<Slowko> slowka)
        {
            Random random = new Random();
            
            return slowka.OrderBy(x => random.Next()).FirstOrDefault();
        }

        private List<Slowko> LosujMozliweOdpowiedzi(Slowko wybraneSlowo)
        {
            wszystkieOdpowiedzi.Remove(wybraneSlowo);

            Random random = new Random();
            var losoweOdpowiedzi = wszystkieOdpowiedzi.OrderBy(x => random.Next()).Take(3).ToList();

            int indexDodanejOdpowiedzi = random.Next(4);
            if (indexDodanejOdpowiedzi == 3)
            {
                losoweOdpowiedzi.Add(wybraneSlowo);
            }
            else
            {
                losoweOdpowiedzi.Insert(indexDodanejOdpowiedzi, wybraneSlowo);
            }

            return losoweOdpowiedzi;
        }
    }

    public class TestTrudny : ITest
    {
        int iloscPytan = 6;
        List<Slowko> slowaDoTestu = new List<Slowko>();
        List<Slowko> wszystkieOdpowiedzi=new List<Slowko>();
        Frame mainFrame;
        public TestTrudny(List<Slowko> slowa)
        {
            this.mainFrame = MainFrameSingleton.Instance; 

            slowaDoTestu = slowa;
            PobierzSlowkaZBazy();

        }
        private void PobierzSlowkaZBazy()
        {
            var dbContext = DBContext.GetInstance;
            wszystkieOdpowiedzi = dbContext.WszystkieSlowka.ToList();
        }
        
        protected  Slowko LosujSlowo(List<Slowko> slowka)
        {
            Random random = new Random();
            return slowka.OrderBy(x => random.Next()).FirstOrDefault();
        }

        private void WylosujSlowa()
        {

            for (int i = 0; i < iloscPytan; i++)
            {
                Slowko wybrane = LosujSlowo(wszystkieOdpowiedzi);
                wszystkieOdpowiedzi.Remove(wybrane);
                slowaDoTestu.Add(wybrane);
            }
        }

        public void WykonajTest()
        {for(int i = 0; i < iloscPytan; i++)
            {

               // WylosujSlowa();
            }
            EgzaminWpiszSlowko egzamin = new EgzaminWpiszSlowko(wszystkieOdpowiedzi,mainFrame);
            Console.WriteLine("Test trudny");
            mainFrame.Navigate(egzamin);
            
        }
    }
}
