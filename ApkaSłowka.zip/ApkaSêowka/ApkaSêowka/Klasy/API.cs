﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using ApkaSłowka.BazaDanych;
using Newtonsoft.Json;

namespace ApkaSłowka.Klasy
{
    class API
    {
        private static readonly string key = "4ac10e1b851149d891d5ecef0a22ce8d";
        private static readonly string endpoint = "https://api.cognitive.microsofttranslator.com";
        private static readonly string location = "westeurope";

        public static Response[] StartSynchronously(Slowko wybrane)
        {
            string route = "/dictionary/examples?api-version=3.0&from=en&to=pl";
            var requestData = new[]
            {
        new { Text = wybrane.angielskie, Translation = wybrane.polskie }
            };

            var requestBody = JsonConvert.SerializeObject(requestData);

            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(endpoint + route);
                request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                request.Headers.Add("Ocp-Apim-Subscription-Key", key);
                request.Headers.Add("Ocp-Apim-Subscription-Region", location);

                try
                {
                    HttpResponseMessage response = client.SendAsync(request).Result; 

                    response.EnsureSuccessStatusCode();
                    string result = response.Content.ReadAsStringAsync().Result;

                    var responseData = JsonConvert.DeserializeObject<Response[]>(result);

                    if (responseData != null && responseData.Length > 0)
                    {
                        var examples = responseData[0]?.Examples;

                        if (examples != null && examples.Any())
                        {
                            string englishSentence = examples[0].SourcePrefix + examples[0].SourceTerm + examples[0].SourceSuffix;
                            string polishSentence = examples[0].TargetPrefix + examples[0].TargetTerm + examples[0].TargetSuffix;

                            Console.WriteLine("Zdanie po angielsku: " + englishSentence);
                            Console.WriteLine("Zdanie po polsku: " + polishSentence);
                        }else
                        {

                            return null;
                        }
                    }

                    return responseData;
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine($"Wystąpił błąd HTTP: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Wystąpił błąd: {ex.Message}");
                }

                return null;
            }
        }

    }

    public class Response
    {
        public string NormalizedSource { get; set; }
        public string NormalizedTarget { get; set; }
        public Example[] Examples { get; set; }
    }

    public class Example
    {
        public string SourcePrefix { get; set; }
        public string SourceTerm { get; set; }
        public string SourceSuffix { get; set; }
        public string TargetPrefix { get; set; }
        public string TargetTerm { get; set; }
        public string TargetSuffix { get; set; }
    }
}
