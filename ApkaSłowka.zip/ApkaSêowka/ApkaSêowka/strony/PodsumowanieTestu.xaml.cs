﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy PodsumowanieTestu.xaml
    /// </summary>
    public partial class PodsumowanieTestu : Page
    {
        int punkty;
        int max;
        public PodsumowanieTestu(int punkty,int max)
        {
            InitializeComponent();
            this.punkty = punkty;
            this.max = max;
            podsumowanie.Text = "Twoj wynik to : "+punkty.ToString()+" / "+max.ToString();
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }

    }
}
