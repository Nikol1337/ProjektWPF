﻿using ApkaSłowka.Klasy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ApkaSłowka.BazaDanych;
using System.Windows.Media.Animation;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy EgzaminSredni.xaml
    /// </summary>
    public partial class EgzaminSredni : Page
    {
        private List<Pytanie> pytania;
        private int obecnePytanieIndex = 0;
        private int iloscPytan = 0;
        private int czasEgzaminu = 5 * 60; 
        private System.Windows.Threading.DispatcherTimer timer;
        private Frame MainFrame;
        private int punkty = 0;
        string wybranaOdpowiedz;

        public EgzaminSredni(List<Pytanie> pytania, int iloscPytan,Frame mainFrame)
        {
            InitializeComponent();
            MainFrame = mainFrame;
            this.pytania = pytania;
            this.iloscPytan = pytania.Count;
            PytaniaCounter.Text = $"Pytanie {obecnePytanieIndex + 1}/{iloscPytan}";
           
            TrescPytania.Text = pytania[obecnePytanieIndex].TrescPytania;
           
            foreach (var odpowiedz in pytania[obecnePytanieIndex].MozliweOdpowiedzi)
            {
                ListBoxItem listBoxItem = new ListBoxItem();
                listBoxItem.Content = odpowiedz.angielskie;
                listBoxItem.PreviewMouseDown += ListBoxItem_PreviewMouseDown;
                ListaOdpowiedzi.Items.Add(listBoxItem);
               
            }
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
            // Inicjalizacja timera
            timer = new System.Windows.Threading.DispatcherTimer();
            timer.Tick += Timer_Tick;
            timer.Interval = TimeSpan.FromSeconds(1); 
            timer.Start();
           
        }

        private void DalejButton_Click(object sender, RoutedEventArgs e)
        {
            
            SprawdzOdpowiedz(wybranaOdpowiedz);
           
            if (obecnePytanieIndex < iloscPytan - 1)
            {
                obecnePytanieIndex++;
                PytaniaCounter.Text = $"Pytanie {obecnePytanieIndex + 1}/{iloscPytan}";
                TrescPytania.Text = pytania[obecnePytanieIndex].TrescPytania;

                ListaOdpowiedzi.Items.Clear();
                foreach (var odpowiedz in pytania[obecnePytanieIndex].MozliweOdpowiedzi)
                {
                    ListBoxItem listBoxItem = new ListBoxItem();
                    listBoxItem.Content = odpowiedz.angielskie;
                    listBoxItem.PreviewMouseDown += ListBoxItem_PreviewMouseDown;
                    ListaOdpowiedzi.Items.Add(listBoxItem);

                   
                }
              
            }
            else
            {
                // Koniec egzaminu
                timer.Stop();
                MessageBox.Show("Koniec egzaminu!");
                PodsumowanieTestu podsumowanie = new PodsumowanieTestu(punkty, iloscPytan);
                MainFrame.Navigate(podsumowanie);
            }
        }
       
        private void SprawdzOdpowiedz(string wybranaOdpowiedz)
        {
            
            
            if (wybranaOdpowiedz == pytania[obecnePytanieIndex].PoprawnaOdpowiedz)
            {
                punkty++;
                OdpowiedzPoprawna(pytania[obecnePytanieIndex].idSlowa);
            }
            else
            {
                OdpowiedzNiepoprawna(pytania[obecnePytanieIndex].idSlowa);
            }
           
        }
        private void OdpowiedzPoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            //var slowoToRemove = db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.PoprawneOdpowiedzi++;
            db.SaveChanges();


        }
        private void OdpowiedzNiepoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            //var slowoToRemove = db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.NiepoprawneOdpowiedzi++;
            db.SaveChanges();


        }
        private void ListBoxItem_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            
            ListBoxItem listBoxItem = (ListBoxItem)sender;
            listBoxItem.Background = Brushes.LightBlue;
            listBoxItem.Foreground = Brushes.White;

           
             wybranaOdpowiedz = listBoxItem.Content.ToString();

            foreach (ListBoxItem item in ListaOdpowiedzi.Items)
            {
                item.Background = Brushes.Transparent;
                item.Foreground = Brushes.White;
            }
        }


        private void Timer_Tick(object sender, EventArgs e)
        {
            
            czasEgzaminu--;

            if (czasEgzaminu == 0)
            {
                // Koniec czasu
                timer.Stop();
                MessageBox.Show("Czas egzaminu minął!");
                PodsumowanieTestu podsumowanie = new PodsumowanieTestu(punkty, iloscPytan);
                MainFrame.Navigate(podsumowanie);
            }
            int minuty = czasEgzaminu / 60;
            int sekundy = czasEgzaminu % 60;
            
            CzasCounter.Text = $"Czas: {minuty:D2}:{sekundy:D2}";
            
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }
    }
}

