﻿using ApkaSłowka.Klasy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ApkaSłowka.BazaDanych;
using static System.Net.Mime.MediaTypeNames;
using System.Windows.Media.Animation;

namespace ApkaSłowka.strony
{
    public partial class TestWielokrotnyWybor : Page
    {
        List<Pytanie >test;
        Pytanie aktualnePytanie = null;
        int nrPytania = 0;
        int punkty = 0;
        private readonly Frame _mainFrame;
        int maksymalna = 4;
        string jezyk;
        public TestWielokrotnyWybor(List<Pytanie> pytanie,Frame main,int iloscPytan,string jezyk)
        {
            InitializeComponent();
            maksymalna = iloscPytan;
            this.test = pytanie;
            this.jezyk = jezyk;
            aktualnePytanie = test[nrPytania];
            WyswietlKolejnePytanie();
            _mainFrame = main;
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;

        }
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton radioButton)
            {
                string wybranaOdpowiedz = radioButton.Content.ToString();
                sprawdzCzyPoprawnaOdpowiedz(wybranaOdpowiedz);
            }
        }
      private void sprawdzCzyPoprawnaOdpowiedz(string wybranaOdpowiedz)
        {
            if (wybranaOdpowiedz == aktualnePytanie.PoprawnaOdpowiedz)
            {
                punkty++;
                OdpowiedzPoprawna(aktualnePytanie.idSlowa);
                Reakcja.Text = "Świetnie!! Poprawna odpowiedz!";
            }
            else
            {
                OdpowiedzNiepoprawna(aktualnePytanie.idSlowa);
                Reakcja.Text = "Niestety to błędna odpowiedź";
            }
            radioButtonOdpowiedzA.IsEnabled = false;
            radioButtonOdpowiedzB.IsEnabled = false;
            radioButtonOdpowiedzC.IsEnabled = false;
            radioButtonOdpowiedzD.IsEnabled = false;
        }
        private void Button_NastepnePytanie_Click(object sender, RoutedEventArgs e)
        {
            
            if (nrPytania < (test.Count-1)) { 
            nrPytania++;
            aktualnePytanie = test[nrPytania];
            WyswietlKolejnePytanie();
            }else
            {
                WyswietlPodsumowanie();
            }

        }
        private void WyswietlPodsumowanie()
        {
            PodsumowanieTestu podsumowanie=new PodsumowanieTestu(punkty,maksymalna);
            _mainFrame.Navigate(podsumowanie);

        }
        private void OdpowiedzPoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            //var slowoToRemove = db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.PoprawneOdpowiedzi++;
            db.SaveChanges();


        }
        private void OdpowiedzNiepoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            //var slowoToRemove = db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.NiepoprawneOdpowiedzi++;
            db.SaveChanges();


        }
        private void WyswietlKolejnePytanie()
        {
            radioButtonOdpowiedzA.IsEnabled = true;
            radioButtonOdpowiedzB.IsEnabled = true;
            radioButtonOdpowiedzC.IsEnabled = true;
            radioButtonOdpowiedzD.IsEnabled = true;
            radioButtonOdpowiedzA.IsChecked = false;
            radioButtonOdpowiedzB.IsChecked = false;
            radioButtonOdpowiedzC.IsChecked = false;
            radioButtonOdpowiedzD.IsChecked = false;
            Reakcja.Text = "";
            textBlockPytanie.Text = test[nrPytania].TrescPytania;
            if (jezyk == "Polski") { 
            radioButtonOdpowiedzA.Content = test[nrPytania].MozliweOdpowiedzi[0].polskie;
            radioButtonOdpowiedzB.Content = test[nrPytania].MozliweOdpowiedzi[1].polskie;
            radioButtonOdpowiedzC.Content = test[nrPytania].MozliweOdpowiedzi[2].polskie;
            radioButtonOdpowiedzD.Content = test[nrPytania].MozliweOdpowiedzi[3].polskie;
            }
            else
            {
                radioButtonOdpowiedzA.Content = test[nrPytania].MozliweOdpowiedzi[0].angielskie;
                radioButtonOdpowiedzB.Content = test[nrPytania].MozliweOdpowiedzi[1].angielskie;
                radioButtonOdpowiedzC.Content = test[nrPytania].MozliweOdpowiedzi[2].angielskie;
                radioButtonOdpowiedzD.Content = test[nrPytania].MozliweOdpowiedzi[3].angielskie;

            }
        }

        //ANIMACJA STRONY

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }

    }
}
