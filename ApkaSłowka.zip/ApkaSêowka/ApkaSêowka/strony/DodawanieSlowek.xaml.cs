﻿using ApkaSłowka.BazaDanych;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy DodawanieSlowek.xaml
    /// </summary>
    public partial class DodawanieSlowek : Page
    {
        private DBContext dbContext;
        public DodawanieSlowek()
        {
            dbContext = DBContext.GetInstance;
            InitializeComponent();
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
        }
        private void DodajDoBazyDanych_Click(object sender, RoutedEventArgs e)
        {
            ListaSlowek.Items.Clear();
            string polskie = txtPolskie.Text;
            string angielskie = txtAngielskie.Text;
            bool znane = chkZnane.IsChecked ?? false;

            Slowko noweSlowko = new Slowko
            {
                polskie = polskie,
                angielskie = angielskie,
                Znane = znane
            };
            dbContext.WszystkieSlowka.Add(noweSlowko);
            dbContext.SaveChanges();
            ListaSlowek.Items.Add("Dodano do bazy -" + noweSlowko.Wyświetl());
            
        }

        private void OdczytajZBazyDanych_Click(object sender, RoutedEventArgs e)
        {
           
            ListaSlowek.Items.Clear();
            var wszystkieSłowa = dbContext.WszystkieSlowka.ToList();

            foreach (var slowo in wszystkieSłowa)
            {
                ListaSlowek.Items.Add(slowo.Wyświetl());
                
            }
        }
        private void UsunButton_Click(object sender, RoutedEventArgs e)
        {
            
            String oba = (String)ListaSlowek.SelectedItem;
            if(oba != null)
            {
                string[] slowa = oba.Split(' ');
                string pierwsze = slowa[0];
                Slowko slowo = dbContext.WszystkieSlowka.Where(s => s.polskie == pierwsze).First();
                dbContext.WszystkieSlowka.Remove(slowo);
              //dbContext.WszystkieSlowka.Remove(slowo);
                dbContext.SaveChanges();
            }else
            {
                MessageBox.Show("Nie wybrałeś żadnego słówka", "Uwaga", MessageBoxButton.OK, MessageBoxImage.Warning);

            }
            OdczytajZBazyDanych_Click(sender, e);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }
    }
}
