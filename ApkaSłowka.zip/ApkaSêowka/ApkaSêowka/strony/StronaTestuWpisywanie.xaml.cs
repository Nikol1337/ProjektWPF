﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ApkaSłowka.BazaDanych;
using ApkaSłowka.Klasy;
using static System.Net.Mime.MediaTypeNames;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy StronaTestuWpisywanie.xaml
    /// </summary>
    public partial class StronaTestuWpisywanie : Page
    {
        List<Slowko> slowkaDoTestu;
        int nrPytania = 0;
        int punkty = 0;
        int iloscPytan = 5;
        Frame MainFrame;
        public StronaTestuWpisywanie(List<Slowko> wybranePytaniaDoTestu, Frame mainFrame)
        {
            slowkaDoTestu = wybranePytaniaDoTestu;
            punkty = 0;
            nrPytania = 0;
            MainFrame = mainFrame;

            InitializeComponent();
            textBlockPytanie.Text = ""+ slowkaDoTestu[nrPytania].polskie + "";
            Reakcja.Visibility = Visibility.Collapsed;
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
        }
        private void Button_Sprawdz_Click(object sender, RoutedEventArgs e)
        {
            string odpowiedz = MojePoleTekstowe.Text.ToString().ToLower();
            string oczyszczonyTekst = odpowiedz.Trim();
            string odpowiedzPrawidlowa = slowkaDoTestu[nrPytania].angielskie.ToLower();
            if (oczyszczonyTekst== odpowiedzPrawidlowa)
            {
                Reakcja.Text="Doskonale! Udzielono poprawnej odpowiedzi!";
                Reakcja.Visibility = Visibility.Visible;
            }else
            {
                Reakcja.Text = "Niestety, to błędna odpowiedź.";
                Reakcja.Visibility = Visibility.Visible;
            }
        }
        private void OdpowiedzPoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.PoprawneOdpowiedzi++;
            db.SaveChanges();


        }
        private void OdpowiedzNiepoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.NiepoprawneOdpowiedzi++;
            db.SaveChanges();


        }
        private void Button_NieZnamSlowka_Click(object sender, RoutedEventArgs e)
        {
            textBlockPytanie.Text = "Poprawna odpowiedz to : ";
            MojePoleTekstowe.Text = slowkaDoTestu[nrPytania].angielskie;
            MojePoleTekstowe.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0));
        }
        private void Button_NastepnePytanie_Click(object sender, RoutedEventArgs e)
        {
            string odpowiedz = MojePoleTekstowe.Text.ToString().ToLower();
            string oczyszczonyTekst = odpowiedz.Trim();
            string odpowiedzPrawidlowa = slowkaDoTestu[nrPytania].angielskie.ToLower();
            if (oczyszczonyTekst == odpowiedzPrawidlowa)
            {
                punkty++;
                OdpowiedzPoprawna(slowkaDoTestu[nrPytania].SlowkoId);
            }
            else
            {
                OdpowiedzNiepoprawna(slowkaDoTestu[nrPytania].SlowkoId);
            }
            nrPytania++;
            if (nrPytania < slowkaDoTestu.Count)
            {
                textBlockPytanie.Text = ""+slowkaDoTestu[nrPytania].polskie+"";
                MojePoleTekstowe.Text = "";
                MojePoleTekstowe.Foreground = Brushes.Black;
                Reakcja.Text = " ";
            }
            else
            {
                PodsumowanieTestu podsumowanie = new PodsumowanieTestu(punkty, slowkaDoTestu.Count);
                MainFrame.Navigate(podsumowanie);
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }

    }
}
