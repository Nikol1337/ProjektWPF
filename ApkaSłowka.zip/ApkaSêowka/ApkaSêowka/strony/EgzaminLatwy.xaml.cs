﻿using ApkaSłowka.BazaDanych;
using ApkaSłowka.Klasy;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy EgzaminLatwy.xaml
    /// </summary>
    public partial class EgzaminLatwy : Page
    {
        List<Slowko> listaWszystkichSlowek = new List<Slowko>();
        List<KategoriaSłówek> listaWszystkichKategorii = new List<KategoriaSłówek>();
        Frame mainFrame;
        public EgzaminLatwy(List<Slowko> lista, List<KategoriaSłówek> listaslowek, Frame mainFrame)
        {
            this.mainFrame = mainFrame;
            listaWszystkichSlowek = lista; ;
            listaWszystkichKategorii = listaslowek;
            InitializeComponent();
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
        }
        private void ButtonCategoryZnane_Click(object sender, RoutedEventArgs e)
        {
            Random random = new Random();
            List<Slowko> LISTA = listaWszystkichSlowek.Where(s=>s.Znane==true).OrderBy(s => random.Next()).Take(4).ToList();

            StronaTestuWpisywanie strona = new StronaTestuWpisywanie(LISTA, mainFrame);
            mainFrame.Navigate(strona);
            
            MessageBox.Show("Wybrano Kategorię 1");
            
        }

        private void ButtonCategoryŁatwe_Click(object sender, RoutedEventArgs e)
        {

            Random random = new Random();
            List<Slowko> LISTA = listaWszystkichKategorii[1].Słówka.OrderBy(s => random.Next()).Take(4).ToList();

            StronaTestuWpisywanie strona = new StronaTestuWpisywanie(LISTA, mainFrame);
            mainFrame.Navigate(strona);

            MessageBox.Show("Wybrano Kategorię 2");

        }

        private void ButtonCategoryTrudne_Click(object sender, RoutedEventArgs e)
        {
            List<Pytanie> pytania = new List<Pytanie>();
            pytania = losujPytania(listaWszystkichKategorii[0]);

            TestWielokrotnyWybor strona = new TestWielokrotnyWybor(pytania, mainFrame, 5, "Polski");
            mainFrame.Navigate(strona);


            
            MessageBox.Show("Wybrano Kategorię 3");
            
        }
        private List<Pytanie> losujPytania(KategoriaSłówek kategoria)
        {
            Random random = new Random();
            List<Pytanie> pytania = new List<Pytanie>();
            List<Slowko> slowa = kategoria.Słówka.OrderBy(s => random.Next()).Take(5).ToList();
            foreach (Slowko slowo in slowa)
            {
                Pytanie test = new Pytanie
                {
                    TrescPytania = $"Wybierz prawdiłową odpowiedz: {slowo.angielskie} to po polsku...",
                    MozliweOdpowiedzi = LosujMozliweOdpowiedzi(slowo),
                    PoprawnaOdpowiedz = slowo.polskie,
                    idSlowa = slowo.SlowkoId
                };
                pytania.Add(test);  
            }
           

            return pytania;
        }
        private List<Slowko> LosujMozliweOdpowiedzi(Slowko slowo)
        {
            List<Slowko> slowa = listaWszystkichSlowek;
            // Usunięcie odpowiedzi prawidłowej z listy, aby uniknąć powtórzeń
            slowa.Remove(slowo);

           
            Random random = new Random();

            
            var losoweOdpowiedzi = slowa.OrderBy(x => random.Next()).Take(3).ToList();

            
            int indexDodanejOdpowiedzi = random.Next(4);
            if (indexDodanejOdpowiedzi == 3)
            {
                losoweOdpowiedzi.Add(slowo);
            }
            else
            {
                losoweOdpowiedzi.Insert(indexDodanejOdpowiedzi, slowo);
            }

            return losoweOdpowiedzi;

        }

        private void OnMouseEnter(object sender, MouseEventArgs e)
        {
            Border border = sender as Border;
            if (border != null)
            {
                border.BorderBrush = GetBorderBrushColor(border);
            }
        }

        private void OnMouseLeave(object sender, MouseEventArgs e)
        {
            Border border = sender as Border;
            if (border != null)
            {
                border.BorderBrush = new SolidColorBrush(Color.FromRgb(35, 35, 35));
            }
        }

        private Brush GetBorderBrushColor(Border border)
        {
            // Zwraca odpowiedni kolor na podstawie TextBlock w Border
            var textBlock = border.Child as StackPanel;
            if (textBlock != null)
            {
                var title = textBlock.Children[0] as TextBlock;
                if (title != null)
                {
                   
                        return new SolidColorBrush(Color.FromRgb(87, 135, 163)); // #5787A3

                }
            }
            return Brushes.Transparent;
        }
           
        //ANIMACJE PŁYNNEGO OTWIERANIA OKNA
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }

    }
}
