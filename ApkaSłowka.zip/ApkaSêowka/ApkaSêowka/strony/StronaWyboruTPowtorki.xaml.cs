﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using ApkaSłowka.Klasy;
using ApkaSłowka.BazaDanych;
using LiveCharts;
using LiveCharts.Wpf;
using System.Windows.Media.Animation;

namespace ApkaSłowka.strony
{
    public partial class StronaWyboruTPowtorki : Page
    {
        public TrybPowtorki tryb;
        private readonly Frame _mainFrame;
        List<SlowkoStatystyki> danetabeli = new List<SlowkoStatystyki>();



        public StronaWyboruTPowtorki()
        {


            tryb = new TrybPowtorki();
            _mainFrame = MainFrameSingleton.Instance;

            InitializeComponent();
            LoadData();
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
        }
        private void Zaznaczony(object sender, EventArgs e)
        {

        }
        private void Odznaczony(object sender, EventArgs e)
        {


        }
        private void RozpocznijPowtorke_Click(object sender, RoutedEventArgs e)
        {
            string wybranyRodzajGlowny = ((ComboBoxItem)cmbRodzajGlowny.SelectedItem)?.Name.ToString();

            if (string.IsNullOrEmpty(wybranyRodzajGlowny))
            {
                MessageBox.Show("Proszę wybrać główny rodzaj powtórki.");
                return;
            }
            bool isSelected = true;
            switch (wybranyRodzajGlowny)
            {
                case "test":
                    tryb.UstawAktualnyTypNauki(new NaukaPoprzezTestWielokrotnegoWyboruLuka(_mainFrame));

                    break;
                case "wpisywanie":
                    tryb.UstawAktualnyTypNauki(new NaukaPoprzezWpisywanieSlow(_mainFrame));
                    break;
                default:
                    isSelected = false;
                    break;
            }
            if (isSelected == true) tryb.aktualnyTypNauki.AlgorytmSzablonowy();

        }

        private void cmbRodzajGlowny_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbRodzajGlowny.SelectedItem != null)
            {
                ComboBoxItem selectedItem = (ComboBoxItem)cmbRodzajGlowny.SelectedItem;
                string wybranyRodzajGlowny = selectedItem.Name.ToString();
            }
        }


        private void LoadData()
        {

            foreach (var slowo in DBContext.GetInstance.WszystkieSlowka)
            {
                danetabeli.Add(new SlowkoStatystyki(slowo));
            }

            dataGrid.ItemsSource = danetabeli;
        }

        public List<SlowkoStatystyki> WyszukajSlowa(string query)
        {

            var wyszukanedane = new List<SlowkoStatystyki>();
            wyszukanedane = danetabeli.Where(s => s.polskie.ToLower().Contains(query)).ToList();
            foreach (var slowko in danetabeli.Where(s => s.angielskie.ToLower().Contains(query)).ToList())
            {
                wyszukanedane.Add(slowko);
            }
            return wyszukanedane;
            //dataGrid.ItemsSource =  danetabeli.Where(s => s.polskie.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        private void searchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string query = searchTextBox.Text.ToLower();
            if (string.IsNullOrEmpty(query))
            {
                dataGrid.ItemsSource = danetabeli;
            }
            else
            {
                var results = WyszukajSlowa(query);

                dataGrid.ItemsSource = results;
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }
    }
}

