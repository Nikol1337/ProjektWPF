﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using ApkaSłowka.BazaDanych;
using ApkaSłowka.Klasy;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy Slowniczek.xaml
    /// </summary>
    /// 
    public partial class Slowniczek : Page { 
    public Slowniczek(List<Slowko> lista, List<KategoriaSłówek> kategorie)
    {
        InitializeComponent();
        DataContext = new SlowniczekViewModel
        {
            ListaSlowek = new ObservableCollection<Slowko>(lista),
            KategorieSlowek = new ObservableCollection<KategoriaSłówek>(kategorie)
        };
    }
    }
    /*
    public partial class Slowniczek : Page
    {
        List<Slowko> listaSlowek = new List<Slowko>();
        List<Button> buttons = new List<Button>(); //buttony przyciskow dodawnia do kategorii
        List<Button> buttonsDoUsuwania = new List<Button>();//buttony przyciskow usuwania z kategorii
        
        List<StackPanel> stackPanels = new List<StackPanel>();
        string WybranaKategoria;
        List<KategoriaSłówek> kategorieSlowek;
        public Slowniczek(List<Slowko> lista,List<KategoriaSłówek> kategorie)
        {
            InitializeComponent();
            kategorieSlowek = kategorie;
            listaSlowek = lista;
            WyswietlSlowka();
        }
        private void WyswietlSlowka()
        {
            foreach (var slowo in listaSlowek)
            {
                var stackPanel = new StackPanel { Orientation = Orientation.Horizontal };

                var textBlock = new TextBlock
                {
                    Text = slowo.polskie + " - " + slowo.angielskie,
                    Margin = new Thickness(0, 3, 10, 0),
                    FontSize=18,
                    FontStyle = FontStyles.Italic
                };

                var checkbox = new CheckBox
                {
                    Content = "Znam",
                    Tag = slowo,
                    IsChecked = slowo.Znane,
                    Margin = new Thickness(0, 5, 10, 0),
                    FontSize =18
                };

                var button = new Button
                {
                    Content = " Dodaj ",
                    Tag = slowo,
                    FontSize = 18,
                    Margin = new Thickness(7, 3, 0, 0),
                    IsEnabled = false
                    
                };
                DodajImageDoButtona(button, new Uri("pack://application:,,,/ApkaSłowka;component/Images/minus.png"));
                var toolTip = new ToolTip
                {
                    Content = "Dodaj słowo do kategorii"
                };

                // Przypisanie ToolTip do przycisku
                button.ToolTip = toolTip;
                var buttonUsuwania = new Button
                {
                    Content = " Usuń ",
                    Tag = slowo,
                    FontSize = 18,
                    Margin = new Thickness(7, 3, 0, 0),
                    IsEnabled = false

                };
                var toolTip2 = new ToolTip
                {
                    Content = "Usuń słowo z kategorii"
                };

                // Przypisanie ToolTip do przycisku
                buttonUsuwania.ToolTip = toolTip2;
                buttonsDoUsuwania.Add(buttonUsuwania);
                buttons.Add(button);
                
                button.Click += DodajDoKategorii_Click;
                buttonUsuwania.Click += UsunZKategorii_Click;
                checkbox.Checked += ZmienCzyZnane_Click;
                checkbox.Unchecked += ZmienCzyZnane_Click;

                stackPanel.Children.Add(textBlock);
                stackPanel.Children.Add(checkbox);
                stackPanel.Children.Add(button);
                stackPanel.Children.Add(buttonUsuwania);
                stackPanels.Add(stackPanel);
                ListaSlowek.Items.Add(stackPanel);
            }
        }
        //Dodajemy ikone do buttona
        private void DodajImageDoButtona(Button b,Uri u)
        {
            Image image = new Image();
            image.Source = new BitmapImage(u);
            image.Width = 40;
            image.Height = 40;
            b.Content = image;
        }
        private void ZmienCzyZnane_Click(object sender, RoutedEventArgs e)
        {
            
            Slowko slowo;
            if (sender is CheckBox checkbox)
            {
                
                slowo = checkbox.Tag as Slowko;
                ZmienCzyZnane(slowo);

                
            }
        }

        private void ZmienCzyZnane(Slowko slowo)
        {
            
                DBContext kontekst = DBContext.GetInstance;
                if(slowo.Znane == true)
                kontekst.WszystkieSlowka.Find(slowo.SlowkoId).Znane = false;
                else
                    kontekst.WszystkieSlowka.Find(slowo.SlowkoId).Znane = true;
                kontekst.SaveChanges();
               
            
        }
        private void UsunZKategorii_Click(object sender, RoutedEventArgs e)
        {
            Slowko slowo;
            if(sender is Button clickedButton)
            {
                slowo=clickedButton.Tag as Slowko;
                UsunZKategorii(WybranaKategoria, slowo);

            }
            else
            {
                slowo = null;
            }
            MessageBox.Show($"Usunięto słowo '{slowo.angielskie}' z kategorii!", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void DodajDoKategorii_Click(object sender, RoutedEventArgs e)
        {
            
            var button = (Button)sender;
            Slowko slowo;
            if (sender is Button clickedButton)
            {
                
                slowo = clickedButton.Tag as Slowko;
                DodajDoKategorii(WybranaKategoria, slowo);

                
            }
            else
            {
                slowo = null;
            }
            

            MessageBox.Show($"Dodano słowo '{slowo.angielskie}' do kategorii!");
        }
        private void DodajDoKategorii(string nazwaKategorii,Slowko slowo)
        {
            if (nazwaKategorii == "Łatwe")
            {//kategoriaslowek[1] to kategoria slowek latwych
                kategorieSlowek[1].Słówka.Add(slowo);
                //Zmiany w bazie danych
                DBContext db = DBContext.GetInstance;
                var slowoToRemove = db.WszystkieSlowka.First(s => s.SlowkoId == slowo.SlowkoId);//pobranie slowka z bazy
                db.WszystkieSlowka.Remove(slowoToRemove); //usuniecie z ogolnej bazy slowek
                db.SaveChanges();
                db.KategorieSlowek.Find(2).Słówka.Add((slowo) );//dodanie do bazy danej kategorii
                db.SaveChanges();
                listaSlowek=db.WszystkieSlowka.ToList();//pobranie nowej juz zaktualizowanej listy wszystkich slowek
                Wyczysc();
                WyswietlSlowka();

            }else if (nazwaKategorii == "Trudne")
            {//kategoriaslowek[0] to kategoria slowek trudnych
                kategorieSlowek[0].Słówka.Add(slowo);
                
                DBContext db = DBContext.GetInstance;
                var slowoToRemove = db.WszystkieSlowka.First(s => s.SlowkoId == slowo.SlowkoId);
                db.WszystkieSlowka.Remove(slowoToRemove);
                db.SaveChanges();
                db.KategorieSlowek.Find(1).Słówka.Add((slowo));
                db.SaveChanges();
                listaSlowek = db.WszystkieSlowka.ToList();
                Wyczysc();
                WyswietlSlowka();
            }
        }
        private void UsunZKategorii(string nazwaKategorii, Slowko slowo)
        {
            if (nazwaKategorii == "Łatwe")
            {//kategoriaslowek[1] to kategoria slowek latwych
                kategorieSlowek[1].Słówka.Remove(slowo);

                
                DBContext db = DBContext.GetInstance;
                var slowoToRemove = db.KategorieSlowek.Find(2).Słówka.First(s => s.SlowkoId == slowo.SlowkoId); //pobranie slowka z bazy kategorii
                db.KategorieSlowek.Find(2).Słówka.Remove(slowoToRemove); //usuniecie z bazy kategorii danego slowka
                db.SaveChanges();
                db.WszystkieSlowka.Add((slowo)); //dodanie do ogolnej bazy slowek
                db.SaveChanges();
                listaSlowek = db.WszystkieSlowka.ToList(); //pobranie nowej juz zaktualizowanej listy wszystkich slowek
                Wyczysc();
                WyswietlSlowka();

            }
            else if (nazwaKategorii == "Trudne")
            {//kategoriaslowek[0] to kategoria slowek trudnych
                kategorieSlowek[0].Słówka.Remove(slowo);

                DBContext db = DBContext.GetInstance;
                var slowoToRemove = db.KategorieSlowek.Find(1).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
                db.KategorieSlowek.Find(1).Słówka.Remove(slowoToRemove);
                db.SaveChanges();
                db.WszystkieSlowka.Add((slowo));
                db.SaveChanges();
                listaSlowek = db.WszystkieSlowka.ToList();
                Wyczysc();
                WyswietlSlowka();
            }
        }

        //Wyczyszczenie calej listy slowek aby moc od nowa zaladowac w razie potrzeby
        private void Wyczysc()
        {
            ListaSlowek.Items.Clear();
            buttons.Clear();
            buttonsDoUsuwania.Clear();
            
        }
        

        //Aktywacja buttonu ,,dodawanie do kategorii" oraz ,,usuwanie z kategorii" przy slowkach w zalezności od wybranej kategorii
        private void AktywujButtonyDodawaniaKategorii(string nazwaKategorii)
        {
            
            if (nazwaKategorii == "Łatwe")
            {
                for (int i = 0; i < buttons.Count; i++)
                {
                    var element = buttons[i];
                    var element2 = buttonsDoUsuwania[i];
                    Slowko slowo = (Slowko)element.Tag;

                    if (!kategorieSlowek[1].Słówka.Contains(slowo))
                    {
                        element.IsEnabled = true;
                        element2.IsEnabled = false;
                        
                    }
                    else
                    {
                        element.IsEnabled = false;
                        element2.IsEnabled = true;
                    }
                }
            }
            else if(nazwaKategorii =="Trudne")
            {
                for (int i = 0; i < buttons.Count; i++)
                {
                    var element = buttons[i];
                    var element2 = buttonsDoUsuwania[i];
                    Slowko slowo = (Slowko)element.Tag;

                    if (!kategorieSlowek[0].Słówka.Contains(slowo))
                    {
                        element.IsEnabled = true;
                        element2.IsEnabled = false;
                    }
                    else
                    {
                        element.IsEnabled = false;
                        element2.IsEnabled = true;
                    }
                }
            }
            /*
                foreach (var element in buttons)
            {
                Slowko slowo = (Slowko)element.Tag;
                if (( !kategorieSlowek[1].Słówka.Contains(slowo)) && ( !kategorieSlowek[0].Słówka.Contains(slowo)))
                {

                    ((Button)element).IsEnabled = true;
                }
            }
        }


       //Button trudne słowka, wyswietla ilosc elementow na liscie i aktywuje funkcje wyswietlajaca buttony przy slowkach 
        private void TrudneSlowkaButton_Click(object sender, RoutedEventArgs e)
        {
           
            AktywujButtonyDodawaniaKategorii("Trudne");
            Button clickedButton = (Button)sender;
            clickedButton.Background = Brushes.LightBlue;
            Latwe.Background = Brushes.LightGray;
            WybranaKategoria = "Trudne";
            KategoriaOpis.Content = kategorieSlowek[0].Nazwa + " zawiera " + kategorieSlowek[0].Wyświetl() + " elementów";
           
        }

        //Button latwe słowka, wyswietla ilosc elementow na liscie i aktywuje funkcje wyswietlajaca buttony przy slowkach 
        private void LatweSlowkaButton_Click(object sender, RoutedEventArgs e)
        {
           
            AktywujButtonyDodawaniaKategorii("Łatwe");
            Button clickedButton = (Button)sender;
            clickedButton.Background = Brushes.LightBlue;
            Trudne.Background = Brushes.LightGray;
            WybranaKategoria = "Łatwe";
            KategoriaOpis.Content=kategorieSlowek[1].Nazwa + " zawiera " +kategorieSlowek[1].Wyświetl()+ " elementów";
           
        }
    }*/
}
