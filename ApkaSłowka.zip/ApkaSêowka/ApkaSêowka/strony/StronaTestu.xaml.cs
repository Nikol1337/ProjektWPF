﻿using ApkaSłowka.Klasy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy StronaTestu.xaml
    /// </summary>
    public partial class StronaTestu : Page
    {
        private List<IKreatorListener> kreatorzy = new List<IKreatorListener>();
        public StronaTestu(List<IKreatorListener> kreat)
        {
            InitializeComponent();
            kreatorzy = kreat;
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
        }
        private void RozpocznijTest(RodzajTestu rodzajTestu)
        {
            foreach (var kreator in kreatorzy)
            {
                IKreatorListener proba = kreator;
                RodzajTestu rodzaj = ((Kreator)kreator).RodzajTestu;
                if (kreator is Kreator && ((Kreator)kreator).RodzajTestu == rodzajTestu)
                {
                    ((Kreator)kreator).StworzTest();
                    break;
                }
            }
        }
        private async void HardTest_Click(object sender, RoutedEventArgs e)
        {
            //Animacja
            var storyboard = FindResource("Test1Animation") as Storyboard;
            storyboard.Begin(this);

            var storyboard2 = FindResource("Test2Animation") as Storyboard;
            storyboard2.Begin(this);
            //Przejście do rozpoczęcia
            await Task.Delay(500);
            RozpocznijTest(RodzajTestu.Trudny);
        }
        private async void MediumTest_Click(object sender, RoutedEventArgs e)
        {
            //Animacja
            var storyboard = FindResource("Test1Animation") as Storyboard;
            storyboard.Begin(this);

            var storyboard2 = FindResource("Test3Animation") as Storyboard;
            storyboard2.Begin(this);
            //Przejście do rozpoczęcia
            await Task.Delay(500);
            RozpocznijTest(RodzajTestu.Sredni);
        }
        private async void EasyTest_Click(object sender, RoutedEventArgs e)
        {

            //Animacja

            var storyboard = FindResource("Test2Animation") as Storyboard;
            storyboard.Begin(this);

            var storyboard2 = FindResource("Test3Animation") as Storyboard;
            storyboard2.Begin(this);
            //Przejście do rozpoczęcia
            await Task.Delay(500);
            RozpocznijTest(RodzajTestu.Latwy);
        }

        private void ConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            // Logika dla przycisku Zatwierdź i przejdź dalej
            MessageBox.Show("Przycisk Zatwierdź i przejdź dalej został kliknięty");
        }

        private void OnMouseEnter(object sender, MouseEventArgs e)
        {
            Border border = sender as Border;
            if (border != null)
            {
                border.BorderBrush = GetBorderBrushColor(border);
            }
        }

        private void OnMouseLeave(object sender, MouseEventArgs e)
        {
            Border border = sender as Border;
            if (border != null)
            {
                border.BorderBrush = new SolidColorBrush(Color.FromRgb(35,35,35));
            }
        }

        private Brush GetBorderBrushColor(Border border)
        {
            // Zwraca odpowiedni kolor na podstawie TextBlock w Border
            var textBlock = border.Child as StackPanel;
            if (textBlock != null)
            {
                var title = textBlock.Children[0] as TextBlock;
                if (title != null)
                {
                    if (title.Text.Contains("łatwy"))
                        return new SolidColorBrush(Color.FromRgb(76, 175, 80)); // #4CAF50
                    if (title.Text.Contains("średni"))
                        return new SolidColorBrush(Color.FromRgb(255, 193, 7)); // #FFC107
                    if (title.Text.Contains("trudny"))
                        return new SolidColorBrush(Color.FromRgb(244, 67, 54)); // #F44336
                }
            }
            return Brushes.Transparent;
        }

        //ANIMACJE PŁYNNEGO OTWIERANIA OKNA
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;

                storyboard.Begin(this);
            
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }


    }
}
