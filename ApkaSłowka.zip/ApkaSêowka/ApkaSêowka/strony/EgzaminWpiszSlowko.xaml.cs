﻿using ApkaSłowka.BazaDanych;
using ApkaSłowka.Klasy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ApkaSłowka.strony
{
    /// <summary>
    /// Logika interakcji dla klasy EgzaminWpiszSlowko.xaml
    /// </summary>
    public partial class EgzaminWpiszSlowko : Page
    {
       
        private List<Slowko> slowka;
        private int obecneSlowoIndex = 0;
        private Frame MainFrame;
        private int iloscSlowek = 5; // Ilość słówek do wpisania
        private int czasEgzaminu = 5 * 60; // Czas egzaminu w minutach
        private System.Windows.Threading.DispatcherTimer timer;
        int punkty = 0;

        public EgzaminWpiszSlowko(List<Slowko> slowka, Frame mainFrame)
        {
            InitializeComponent();
            MainFrame = mainFrame;
            this.slowka = slowka.Take(iloscSlowek).ToList(); // Wybierz ilość słówek do egzaminu
            WyswietlSlowo();
            timer = new System.Windows.Threading.DispatcherTimer();
            timer.Tick += Timer_Tick;
            timer.Interval = TimeSpan.FromSeconds(1); 
            timer.Start();
            Loaded += Page_Loaded;
            Unloaded += Page_Unloaded;
        }

        private void WyswietlSlowo()
        {
            if (obecneSlowoIndex < slowka.Count)
            {
                PytaniaCounter.Text = $"Pytanie {obecneSlowoIndex + 1}/{iloscSlowek}";
                
                TrescSlowa.Text = $"Wpisz słowo po {(obecneSlowoIndex % 2 == 0 ? "angielsku" : "polsku")}: {(obecneSlowoIndex % 2 == 0 ? slowka[obecneSlowoIndex].polskie : slowka[obecneSlowoIndex].angielskie)}";
                TrescSlowa.Foreground = Brushes.White;
            }
            else
            {
                // Koniec egzaminu
                timer.Stop();
                MessageBox.Show("Koniec egzaminu!");
                PodsumowanieTestu podsumowanie = new PodsumowanieTestu(punkty, iloscSlowek);
                MainFrame.Navigate(podsumowanie);
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            
            czasEgzaminu--;

            if (czasEgzaminu == 0)
            {
                // Koniec czasu
                timer.Stop();
                MessageBox.Show("Czas egzaminu minął!");
                PodsumowanieTestu podsumowanie = new PodsumowanieTestu(punkty, iloscSlowek);
                MainFrame.Navigate(podsumowanie);
            }
            int minuty = czasEgzaminu / 60;
            int sekundy = czasEgzaminu % 60;
           
            CzasCounter.Text = $"Czas: {minuty:D2}:{sekundy:D2}";
            
        }

        private void SprawdzOdpowiedz()
        {
            if (obecneSlowoIndex < slowka.Count)
            {
                string odpowiedz = OdpowiedzTextBox.Text.Trim();

                if (obecneSlowoIndex % 2 == 0)
                {
                    // Sprawdź odpowiedź po polsku
                    if (odpowiedz.ToLower() == slowka[obecneSlowoIndex].angielskie.ToLower())
                    {
                        MessageBox.Show("Poprawna odpowiedź!");
                        punkty++;
                        OdpowiedzPoprawna(slowka[obecneSlowoIndex].SlowkoId);
                    }
                    else
                    {
                        MessageBox.Show("Błędna odpowiedź!");
                        OdpowiedzNiepoprawna(slowka[obecneSlowoIndex].SlowkoId);
                    }
                }
                else
                {
                    // Sprawdź odpowiedź po angielsku
                    if (odpowiedz.ToLower() == slowka[obecneSlowoIndex].polskie.ToLower())
                    {
                        MessageBox.Show("Poprawna odpowiedź!");
                        punkty++;
                        
                    }
                    else
                    {
                        MessageBox.Show("Błędna odpowiedź!");
                    }
                }

                obecneSlowoIndex++;
                OdpowiedzTextBox.Clear();
                WyswietlSlowo();
            }
        }
        private void OdpowiedzPoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            //var slowoToRemove = db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.PoprawneOdpowiedzi++;
            db.SaveChanges();
          
            
        }
        private void OdpowiedzNiepoprawna(int numer)
        {
            DBContext db = DBContext.GetInstance;
            //var slowoToRemove = db.KategorieSlowek.Find(WybranaKategoria.KategoriaSłówekId).Słówka.First(s => s.SlowkoId == slowo.SlowkoId);
            var slowo = db.WszystkieSlowka.First(s => s.SlowkoId == numer);
            slowo.NiepoprawneOdpowiedzi++;
            db.SaveChanges();


        }

        private void DalejButton_Click(object sender, RoutedEventArgs e)
        {
            SprawdzOdpowiedz();
           
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Begin(this);
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            var storyboard = FindResource("PageTransition") as Storyboard;
            storyboard.Stop(this);
        }
    }
}
